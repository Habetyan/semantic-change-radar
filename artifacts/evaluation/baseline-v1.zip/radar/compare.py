"""Passage alignment and conservative, source-grounded change classification."""

from __future__ import annotations

import re
import time
import unicodedata
from collections import Counter, defaultdict, deque
from decimal import Decimal
from difflib import SequenceMatcher
from typing import Any

import numpy as np
from scipy.optimize import linear_sum_assignment

MAX_CHARACTERS = 30_000
MAX_PASSAGES = 80
ALIGNMENT_THRESHOLDS = {"lexical": 0.38, "semantic": 0.55}
EQUIVALENCE_THRESHOLD = 0.78
CONTRADICTION_THRESHOLD = 0.65

# Exact conversions only. Months/years, currencies, temperatures, and ambiguous
# abbreviations such as "m" deliberately require review.
_UNIT_FACTORS = {
    "seconds": ("seconds", 1),
    "second": ("seconds", 1),
    "sec": ("seconds", 1),
    "minutes": ("seconds", 60),
    "minute": ("seconds", 60),
    "min": ("seconds", 60),
    "hours": ("seconds", 3600),
    "hour": ("seconds", 3600),
    "hr": ("seconds", 3600),
    "days": ("seconds", 86400),
    "day": ("seconds", 86400),
    "weeks": ("seconds", 604800),
    "week": ("seconds", 604800),
    "B": ("bytes", 1),
    "kB": ("bytes", 1000),
    "MB": ("bytes", 1000**2),
    "GB": ("bytes", 1000**3),
    "KiB": ("bytes", 1024),
    "MiB": ("bytes", 1024**2),
    "GiB": ("bytes", 1024**3),
}
_MEASUREMENT = re.compile(
    r"(?<![\w.,])([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*(" + "|".join(_UNIT_FACTORS) + r")\b"
)


def _canonical_measurements(text: str) -> str:
    def convert(match: re.Match) -> str:
        dimension, factor = _UNIT_FACTORS[match[2]]
        value = Decimal(match[1].replace(",", "")) * factor
        return f"<{value.normalize():f} {dimension}>"

    return _MEASUREMENT.sub(convert, _content(text))


def _normalize(text: str) -> str:
    return " ".join(unicodedata.normalize("NFC", text).split())


def split_passages(text: str) -> list[str]:
    """Split paragraphs and list items; preserve sentences and soft-wrapped lines.

    A blank line, Markdown heading, or list item starts a new passage. Sentence
    splitting would break decimals and detach exceptions from their conditions.
    """
    if not isinstance(text, str):
        raise ValueError("Documents must be text strings.")
    if len(text) > MAX_CHARACTERS:
        raise ValueError(f"Each document must be at most {MAX_CHARACTERS:,} characters.")
    passages: list[str] = []
    lines: list[str] = []

    def flush() -> None:
        if lines:
            passages.append(" ".join(lines))
            lines.clear()

    for line in text.splitlines():
        line = line.strip()
        if not line:
            flush()
        elif re.match(r"^(?:#{1,6}\s|[-*+]\s|\d+[.)]\s)", line):
            flush()
            lines.append(line)
            if line.startswith("#"):
                flush()
        else:
            lines.append(line)
    flush()
    if len(passages) > MAX_PASSAGES:
        raise ValueError(f"Each document must contain at most {MAX_PASSAGES} passages.")
    return passages


def _content(text: str) -> str:
    # Ignore list numbering/Markdown markers for matching, but retain source text.
    return re.sub(r"^(?:#{1,6}\s+|[-*+]\s+(?!\d)|\d+[.)]\s+)", "", _normalize(text))


def _tokens(text: str) -> list[str]:
    return re.findall(r"\w+(?:['’]\w+)?", _content(text).casefold())


def _lexical_similarity(left: str, right: str) -> float:
    a, b = Counter(_tokens(left)), Counter(_tokens(right))
    if not a or not b:
        return float(_normalize(left) == _normalize(right))
    dot = sum(value * b[word] for word, value in a.items())
    cosine = dot / (sum(v * v for v in a.values()) * sum(v * v for v in b.values())) ** 0.5
    order = SequenceMatcher(None, _tokens(left), _tokens(right), autojunk=False).ratio()
    return 0.75 * cosine + 0.25 * order


def _numbers(text: str) -> tuple[str, ...]:
    # This remains conservative outside the small supported unit vocabulary.
    return tuple(
        number.replace(",", "").replace(" ", "")
        for number in re.findall(r"(?<!\w)[+-]?\s*\d+(?:[.,]\d+)*(?:%)?", _content(text))
    )


def _signals(old: str, new: str) -> tuple[list[str], str]:
    """Return observable text changes, never a generated explanation of intent."""
    quantities_changed = Counter(_MEASUREMENT.findall(old)) != Counter(_MEASUREMENT.findall(new))
    old, new = _content(old).casefold(), _content(new).casefold()
    signals: list[str] = []
    category = "Content change"
    if _numbers(old) != _numbers(new):
        signals.append("Numeric values or their order changed; check quantities, dates, and units.")
        category = "Quantity or date change"
    elif quantities_changed:
        signals.append("Measurement values or units differ.")
        category = "Quantity or date change"
    negation = r"\b(?:not|no|never|cannot|can't|mustn't|without|prohibited|forbidden)\b"
    if bool(re.search(negation, old)) != bool(re.search(negation, new)):
        signals.append("Negation or exclusion wording changed.")
        if category == "Content change":
            category = "Negation change"
    conditions = r"\b(?:only|unless|except|provided that|as long as|whichever|if|until)\b"
    if Counter(re.findall(conditions, old)) != Counter(re.findall(conditions, new)):
        signals.append("A condition, exception, or restriction marker changed.")
        if category == "Content change":
            category = "Condition change"
    obligation = r"\b(?:must|shall|required|mandatory|need to|needs to|has to)\b"
    if bool(re.search(obligation, old)) != bool(re.search(obligation, new)):
        signals.append("Requirement wording changed.")
        if category == "Content change":
            category = "Requirement change"
    roles = r"\b(?:guests?|admins?|administrators?|owners?|members?|visitors?)\b"
    if Counter(re.findall(roles, old)) != Counter(re.findall(roles, new)):
        if re.search(r"\b(?:can|may|allow\w*|permit\w*|access|only)\b", old + " " + new):
            signals.append("Actors in access or permission wording changed.")
            if category in {"Content change", "Condition change"}:
                category = "Permission change"
    # Equal word bags can hide swapped actions, actors, and conditions.
    old_tokens, new_tokens = _tokens(old), _tokens(new)
    if old_tokens != new_tokens and Counter(old_tokens) == Counter(new_tokens):

        def clauses(text: str) -> list[tuple]:
            return sorted(
                tuple(sorted(_tokens(part)))
                for part in re.split(r"\b(?:and|but|while|whereas)\b|;", text)
            )

        def first_content(tokens: list[str]) -> str:
            return next(
                (t for t in tokens if t not in {"the", "a", "an"} and not t.endswith("ly")), ""
            )

        if clauses(old) != clauses(new) or first_content(old_tokens) != first_content(new_tokens):
            signals.append("The same words have different clause or actor assignments.")
            if category == "Content change":
                category = "Actor or scope change"
    return signals, category


def _assign(scores: np.ndarray, threshold: float) -> list[tuple[int, int]]:
    """Global one-to-one matching with explicit zero-benefit unmatched slots."""
    n, m = scores.shape
    if not n or not m:
        return []
    benefits = np.zeros((n + m, n + m))
    benefits[:n, :m] = scores - threshold
    # Stable positional tie-breaking only; it cannot rescue a below-threshold pair.
    for i in range(n):
        for j in range(m):
            benefits[i, j] -= abs(i - j) * 1e-8
    rows, cols = linear_sum_assignment(benefits, maximize=True)
    return [
        (int(i), int(j)) for i, j in zip(rows, cols) if i < n and j < m and scores[i, j] > threshold
    ]


def _base_change(old: list[str], new: list[str], i: int | None, j: int | None) -> dict:
    return {
        "old_index": i,
        "new_index": j,
        "old_text": old[i] if i is not None else "",
        "new_text": new[j] if j is not None else "",
        "moved": False,
        "alignment_score": None,
        "old_entails_new": None,
        "new_entails_old": None,
        "contradiction_score": None,
        "signals": [],
    }


def _classify(change: dict, forward: dict | None, reverse: dict | None) -> None:
    signals, category = _signals(change["old_text"], change["new_text"])
    change["signals"] = signals
    if forward is None or reverse is None:
        change.update(
            status="modified",
            category=category if signals else "Text edit",
            explanation="The lexical baseline flags every non-identical passage as an edit. "
            "It cannot establish whether meaning is preserved.",
        )
        return
    f, r = forward["entailment"], reverse["entailment"]
    contradiction = max(forward["contradiction"], reverse["contradiction"])
    change.update(
        old_entails_new=round(f, 4),
        new_entails_old=round(r, 4),
        contradiction_score=round(contradiction, 4),
    )
    if _canonical_measurements(change["old_text"]) == _canonical_measurements(change["new_text"]):
        change.update(
            status="reworded",
            category="Equivalent units",
            signals=[],
            explanation="Only numeric formatting or exactly convertible duration/storage "
            "units changed; the remaining text is identical.",
        )
    elif signals:
        change.update(
            status="modified",
            category=category,
            explanation="Explicit wording signals indicate a potentially material edit. "
            "Check the highlighted source passages; these signals can produce false alarms.",
        )
    elif min(f, r) >= EQUIVALENCE_THRESHOLD:
        change.update(
            status="reworded",
            category="Wording only",
            explanation="Both passages imply one another according to the NLI model. "
            "This suggests equivalent wording, not a guarantee of equivalence.",
        )
    elif contradiction >= CONTRADICTION_THRESHOLD:
        change.update(
            status="modified",
            category="Contradiction",
            explanation="The NLI model detects a conflict between the aligned statements.",
        )
    elif max(f, r) >= 0.72 and min(f, r) <= 0.35:
        change.update(
            status="modified",
            category="Scope change",
            explanation="The model finds implication in one direction but not the other. "
            "Information may have been added, removed, or qualified.",
        )
    else:
        change.update(
            status="uncertain",
            category="Needs review",
            explanation="The model cannot confidently distinguish a meaning change from "
            "a paraphrase. Review both passages.",
        )


def compare_documents(old_text: str, new_text: str, backend: str = "semantic") -> dict[str, Any]:
    """Compare short documents. Semantic model failures are never hidden."""
    started = time.perf_counter()
    if backend not in ALIGNMENT_THRESHOLDS:
        raise ValueError("Choose the 'semantic' or 'lexical' backend.")
    old, new = split_passages(old_text), split_passages(new_text)
    if not old and not new:
        raise ValueError("Add text to at least one document before comparing.")
    warnings = []
    if backend == "lexical":
        warnings.append(
            "Lexical baseline: wording edits are flagged as changes; no semantic model is used."
        )
    if not old or not new:
        warnings.append("One document is empty; all passages are additions or removals.")

    # Exact matching first avoids spending model time on unchanged passages and
    # preserves multiplicity when a document contains repeated text.
    new_exact: dict[str, deque[int]] = defaultdict(deque)
    for j, passage in enumerate(new):
        new_exact[_content(passage)].append(j)
    matched: list[tuple[int, int]] = []
    changes: list[dict] = []
    for i, passage in enumerate(old):
        available = new_exact[_content(passage)]
        if available:
            j = available.popleft()
            matched.append((i, j))
            change = _base_change(old, new, i, j)
            change.update(
                status="unchanged",
                category="Unchanged",
                alignment_score=1.0,
                explanation="Text is identical after whitespace and list-marker normalization.",
            )
            changes.append(change)
    used_old, used_new = {i for i, _ in matched}, {j for _, j in matched}
    old_remaining = [i for i in range(len(old)) if i not in used_old]
    new_remaining = [j for j in range(len(new)) if j not in used_new]
    model_metadata: dict = {}
    models = None

    if old_remaining and new_remaining:
        lexical = np.array(
            [[_lexical_similarity(old[i], new[j]) for j in new_remaining] for i in old_remaining]
        )
        if backend == "semantic":
            from radar.models import get_models

            models = get_models()
            embeddings = models.encode(
                [old[i] for i in old_remaining] + [new[j] for j in new_remaining]
            )
            split = len(old_remaining)
            semantic = np.clip(embeddings[:split] @ embeddings[split:].T, 0, 1)
            scores = 0.85 * semantic + 0.15 * lexical
            model_metadata = models.metadata()
        else:
            scores = lexical
        assignments = _assign(scores, ALIGNMENT_THRESHOLDS[backend])
        pairs = [(old_remaining[a], new_remaining[b]) for a, b in assignments]
        nli = (
            models.predict_nli(
                [(old[i], new[j]) for i, j in pairs] + [(new[j], old[i]) for i, j in pairs]
            )
            if models and pairs
            else []
        )
        for k, ((a, b), (i, j)) in enumerate(zip(assignments, pairs)):
            change = _base_change(old, new, i, j)
            change["alignment_score"] = round(float(scores[a, b]), 4)
            _classify(change, nli[k] if nli else None, nli[k + len(pairs)] if nli else None)
            # Weak matching should not certify a harmless paraphrase.
            if backend == "semantic" and scores[a, b] < ALIGNMENT_THRESHOLDS[backend] + 0.04:
                change.update(
                    status="uncertain",
                    category="Weak alignment",
                    explanation="Passage correspondence is weak. Check whether these passages "
                    "belong together before interpreting the edit.",
                )
            changes.append(change)
        matched.extend(pairs)

    used_old, used_new = {i for i, _ in matched}, {j for _, j in matched}
    for i in range(len(old)):
        if i not in used_old:
            change = _base_change(old, new, i, None)
            change.update(
                status="removed",
                category="Removed passage",
                explanation="No sufficiently similar passage was found in the revised document.",
            )
            changes.append(change)
    for j in range(len(new)):
        if j not in used_new:
            change = _base_change(old, new, None, j)
            change.update(
                status="added",
                category="Added passage",
                explanation="No sufficiently similar passage was found in the original document.",
            )
            changes.append(change)
    for change in changes:
        i, j = change["old_index"], change["new_index"]
        if i is not None and j is not None:
            change["moved"] = any((i - a) * (j - b) < 0 for a, b in matched)
    changes.sort(
        key=lambda c: (
            c["new_index"] is None,
            c["new_index"] if c["new_index"] is not None else c["old_index"],
        )
    )
    for index, change in enumerate(changes, 1):
        change["id"] = f"change-{index}"
    return {
        "schema_version": 1,
        "engine": backend,
        "old_count": len(old),
        "new_count": len(new),
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
        "warnings": warnings,
        "models": model_metadata,
        "changes": changes,
    }
