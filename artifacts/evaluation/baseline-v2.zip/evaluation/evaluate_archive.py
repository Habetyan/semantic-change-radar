"""Score the archived v1 engine with current group metrics, without importing current inference."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from evaluation.real_evaluate import (
    ROOT,
    cached_model_artifacts,
    evaluate_dataset,
    load_manifest,
    source_hashes,
)
from radar.compare import split_passages

ARCHIVE = ROOT / "artifacts/evaluation/baseline-v1.zip"
WORKER = """
import json, sys, time
sys.path.insert(0, sys.argv[1])
from radar.compare import compare_documents
assert compare_documents.__code__.co_filename.startswith(sys.argv[1] + "/"), "Expected archived inference module"
outcomes = []
for texts in json.load(sys.stdin):
    started = time.perf_counter()
    try:
        result = {"prediction": compare_documents(*texts, backend="semantic")}
    except Exception as exc:
        result = {"error": f"{type(exc).__name__}: {exc}"}
    result["wall_time_ms"] = (time.perf_counter() - started) * 1000
    outcomes.append(result)
print(json.dumps(outcomes))
"""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    manifest = load_manifest(args.manifest)
    inputs, case_keys = [], {}
    for case in manifest["cases"]:
        try:
            texts = tuple(
                (ROOT / case[s]["text_path"]).read_text(encoding="utf-8") for s in ("old", "new")
            )
        except (OSError, UnicodeError):
            continue  # evaluate_dataset reports input failures against the full case denominator.
        case_keys[case["id"]] = texts
        inputs.append(texts)
    started = time.perf_counter()
    worker = subprocess.run(
        [sys.executable, "-c", WORKER, str(ARCHIVE.resolve())],
        input=json.dumps(inputs),
        capture_output=True,
        text=True,
        env={**os.environ, "HF_HUB_OFFLINE": "1"},
    )
    worker_seconds = time.perf_counter() - started
    if worker.returncode:
        results = [
            {"error": f"Archive subprocess failed: {worker.stderr}", "wall_time_ms": None}
            for _ in inputs
        ]
    else:
        results = json.loads(worker.stdout)
        if len(results) != len(inputs):
            raise ValueError("Archive subprocess returned an incomplete outcome list.")
    lookup = dict(zip(inputs, results))

    def compare(old: str, new: str, **contexts) -> dict:
        result = lookup[(old, new)]
        if "error" in result:
            raise RuntimeError(result["error"])
        return result["prediction"]

    summary, predictions = evaluate_dataset(manifest["cases"], compare, split_passages)
    latencies = []
    for prediction in predictions:
        key = case_keys.get(prediction["id"])
        outcome = lookup.get(key, {})
        prediction["validation_wall_time_ms"] = prediction.pop("wall_time_ms")
        prediction["wall_time_ms"] = outcome.get("wall_time_ms")
        if prediction["success"]:
            latencies.append(prediction["wall_time_ms"])
    hashes = source_hashes(args.manifest, manifest)
    hashes[str(Path(__file__).relative_to(ROOT))] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    with zipfile.ZipFile(ARCHIVE) as archive:
        member_hashes = {
            name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()
        }
    summary.update(
        schema_version=2,
        profile="archived_v1",
        backend="semantic",
        created_at=datetime.now(timezone.utc).isoformat(),
        archive={
            "path": str(ARCHIVE.relative_to(ROOT)),
            "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
            "members": member_hashes,
        },
        source_hashes=hashes,
        provenance="Archived v1 inference; current group metrics and input validation. Current radar hashes describe validation/provenance, not executed inference. Context sidecars are ignored by v1.",
        configured_model_artifacts=cached_model_artifacts("semantic"),
        models=next(
            (
                p["prediction"]["models"]
                for p in predictions
                if p.get("prediction", {}).get("models")
            ),
            {},
        ),
        archive_subprocess_seconds=worker_seconds,
        archive_subprocess_stderr=worker.stderr,
        latency_ms={
            "scope": "Archived subprocess compare_documents calls, including first model initialization; excludes parent lookup/scoring and process startup.",
            "first_successful_case": latencies[0] if latencies else None,
            "mean_including_initialization": statistics.mean(latencies) if latencies else None,
            "median": statistics.median(latencies) if latencies else None,
            "p95_nearest_rank": sorted(latencies)[math.ceil(0.95 * len(latencies)) - 1]
            if latencies
            else None,
        },
    )
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    (args.output / "predictions.jsonl").write_text(
        "".join(json.dumps(p) + "\n" for p in predictions), encoding="utf-8"
    )
    (args.output / "archive-outcomes.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    return 0 if summary["complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
